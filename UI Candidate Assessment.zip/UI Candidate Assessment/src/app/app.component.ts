import { Component } from '@angular/core';
import { SourceService } from './source.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'uiAssess';

  constructor(private ds: SourceService) {}
  public SendMessage(): void {
      this.ds.SendMessage('Test');
  }
}

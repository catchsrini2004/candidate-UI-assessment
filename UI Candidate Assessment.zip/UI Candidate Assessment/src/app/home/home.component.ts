import { Component, OnInit } from '@angular/core';
import { SourceService } from '../source.service';
 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private store : SourceService) { }

  jsonData = [];
  selItemVal = ''; 
  groupData = [];
  filterCards = [];
  modelData: any;
  detailsCard: any;
  public Message: string = null;
  ngOnInit(): void {
    
      this.store.message.subscribe((msg) => {
          this.Message = msg;
      })

    this.store.loadData().subscribe(res => {
      this.selItemVal = 'Group 1';
      let data : any;
      data = res;
      this.jsonData = data;

        for(let obj  of data.groups) {
        let grp :any = {};
        grp.value = obj.name;
        grp.id = obj.id;
        grp.cards = obj.cards;

        this.groupData.push(grp);
        this.filterCards =  this.groupData[0].cards;
      }
      this.modelData = this.groupData[0];

    },
    error => {
      console.log('error');
    })
  }

  selItem(event) {
    this.selItemVal = event;
    for(let obj of this.groupData) {
      if (this.selItemVal == obj.value) {
        this.filterCards = obj.cards;

      }
  }
  }

  loadCards(key) {
    let maincard = [];
    for(let obj of this.groupData) {
        if (this.selItemVal == obj.value) {

          maincard = obj.cards;

        }
    }
    this.filterCards = maincard;

    if (key == 1 ) {
      this.filterCards = [];
      let count = 0;
     for(let card of maincard) {
      if (count < 3) {
        this.filterCards.push(card)
        count++;
      }
    }
  }
      else if (key == 2) {
        this.filterCards = [];
        let count = 3;
        for(let i = 3 ;i < maincard.length ; i++) {

          this.filterCards.push(maincard[i])
        }
      }
     
    }


    loadDetails(card) {
      this.detailsCard = card;
    }
    
}
